#include<stdio.h>
void main()
{

    int a=1,b;
    printf("Enter the value of b\n");
    scanf("%d", &b);
    do
    {
    
        printf("Aryan Sabhani \n" );
        a++;
    } while (a<=b);
    
    
}

