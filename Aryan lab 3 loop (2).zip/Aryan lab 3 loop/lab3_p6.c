#include<stdio.h>
void main()

{
    int a = 1;
    int x;

    printf("Enter the value of number you want to print till\n");
    scanf("%d", &x);

    for(a==1;a<=x; a++)
    {
        if(a%2==0)
        {
            printf("%d\n", a);
        }
        
    }

    
}