#include<stdio.h>
void main()

{
    int a,sum=0;
    float mean;

    printf("Enter the value of 10 numbers:\n");

    for(a=1;a<=10;a++)
    {
        printf("Number %d:", a);
        scanf("%d", &a);

        sum=sum+a;


    }

    mean=sum/10.00;

    printf("The sum is 10 number is %d\n", sum);
    printf("The mean of 10 numbers is %.3f", mean);
}