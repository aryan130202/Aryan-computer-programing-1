#include<stdio.h>
void main()
{

    int a=1,b;
    do
    {
    
        printf("Aryan Sabhani \n");
        a++;
    } while (a<6);
    
    
}

