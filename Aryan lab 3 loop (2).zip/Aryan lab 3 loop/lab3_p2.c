#include<stdio.h>

void main()
{
 int a;

 a=1;
 do
 {
 if(a%2!=0)
 {
    printf("%d\n", a);

 }

 a++;
 }while(a<=20);
}
