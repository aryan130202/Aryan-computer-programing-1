#include <stdio.h>
int main() {
    int i, j;
    for (i = 1; i <= 3; i++) {
        if (i == 3) {
            for (j = 1; j <= 3; j++)
                printf("%d %d\n", i, j);
        } else {
            printf("%d 1\n", i);
        }
    }
    return 0;
}

