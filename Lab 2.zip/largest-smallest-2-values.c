#include<stdio.h>

void main()
{
    int a, b;
    printf("Enter the value of A:\n");
    scanf("%d", &a);

    printf("Enter the value of B:\n");
    scanf("%d", &b);

    if(a>b)
    {
        printf(" A is Greater than B \n");
    }

    else
    {
        printf("B is greater than A");
    }
}