#include<stdio.h>
void main()

{
    int marks, maths,geology,computer;
    float average;
    printf("Enter the marks obtained in Maths :\n");
    scanf("%d",&maths);

    
    printf("Enter the marks obtained in Geology :\n");
    scanf("%d",&geology);

    
    printf("Enter the marks obtained in Computer :\n");
    scanf("%d",&computer);

    average=  (maths+geology+computer)/3;
    printf("The total marks obtained of all  subject is: %d\n", maths+geology+computer);
    printf("The average marks of all three subjects are: %.3f\n", average );

    if(average>=70.00)
    {
        printf("Congratulations you have got the distinction in the exams\n");

    }

    else if(average>= 60.00)
    {
        printf("Congratulations you have got the 1st grade in the class\n");

    }

    else if(average>=50.00)
    {
         printf("Congratulations you have got the 2nd grade in the class\n");
    }

    else if(average>=35.00)
    {
         printf("Congratulations you have got 3rd grade in the exams\n");
    }

    else if(average<35.00)
    {
         printf("You have failed in the examination");
    }
}