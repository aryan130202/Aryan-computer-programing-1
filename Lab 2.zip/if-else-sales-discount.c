#include<stdio.h>

void main()
{
    float sales,discount,a;

    printf("Enter the amount of sales done:\n");
    scanf("%f", &sales);

    if(sales>20000)
    {
        discount=sales*15/100;
        printf("The net sales after giving discount is:%.3f", sales-discount);
    }

    else if(sales>10000)
    {
        discount=sales*10/100;
        printf("The net sales after giving discount is :%.3f\n", sales-discount);

    }

    else 
    {
        discount=sales*5/100;
        printf("The net sales after giving the discount is :%.3f\n", sales-discount);
    }
    
}