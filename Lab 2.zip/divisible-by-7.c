#include<stdio.h>

void main()

{
    int a,b;

    printf("Enter the value you want to check the divisibility of :\n");
    scanf("%d", &a);

    if(a%7==0)
    {
        printf("The number entered is divisible by 7\n");

    }

    else
    {
        printf("The number is not exactly divisible by 7");

    }
}