#include<stdio.h>

void main()
{
    int a,b,c;
    
    printf("Enter the value of A, B and C:\n");
    scanf("%d %d %d", &a, &b ,&c);

    if(a>b)
    {
        if(a>c)
        {
            printf("A is the Greatest among all");

        }

        else
        {
            printf("C is gratest among all\n");
        }
    }
    else
    {
        if(b>c)
        {
            printf("B is greatest among all\n");

        }

        else
        {
            printf("C is greatest among all\n");
        }
    }
}