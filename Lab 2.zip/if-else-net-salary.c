#include<stdio.h>
void main()

{
    float a, salary,allowance,deduction ; 

    printf("Enter the salary amount:\n");
    scanf("%f", &salary);
    if(salary>10000)
    {
        allowance=salary*10/100;
        deduction=salary*3/100;

        printf("The net salary is %.2f Rupees", salary+allowance-deduction);
    }

    else if (salary>5000)
    {
        allowance=salary*7/100;
        deduction=salary*2/100;

        printf("The net salary is %.2f Rupees", salary+allowance-deduction);
    }

}